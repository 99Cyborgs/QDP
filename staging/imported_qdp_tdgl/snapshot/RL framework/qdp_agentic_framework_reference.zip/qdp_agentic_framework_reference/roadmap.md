# QDP Agentic Research Roadmap

## Phase 0 — Foundation

Deliver:
- artifact schemas,
- canonical IDs and versioning,
- governance policy,
- tool adapters with contracts,
- trace store,
- basic workflow definition.

Exit criterion:
- every core artifact can be created, validated, stored, and retrieved by ID.

## Phase 1 — Single-loop reliability

Deliver:
- QDP Supervisor,
- Theory Interface,
- Literature Scout,
- low-cost RunSpec generation,
- result ingestion,
- Skeptic pass,
- DecisionMemo drafts.

Exit criterion:
- the primary loop works end-to-end with auditable traces and no uncontrolled actions.

## Phase 2 — Governed workflow graph

Deliver:
- resumable execution,
- approval router,
- contradiction graph,
- worker contracts,
- budget controller,
- improved audit logic.

Exit criterion:
- multi-step workflows can survive tool failure, approvals, and restarts.

## Phase 3 — Portfolio support

Deliver:
- scheduled literature watch,
- queue review summaries,
- portfolio reranking suggestions,
- recurring decision memo generation.

Exit criterion:
- longer-running operations remain bounded, auditable, and useful.
